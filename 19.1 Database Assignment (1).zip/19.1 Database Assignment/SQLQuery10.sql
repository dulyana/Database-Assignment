USE [Library]
GO

/****** Object: SqlProcedure [dbo].[InsertAuthor] Script Date: 03/01/2021 11:55:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[InsertAuthor]
	@Fname varchar,
	@LName varchar,
	@CreatedUserId INT
AS
	INSERT INTO [Author] (Fname,LName,CreatedDate,CreatedUserId) VALUES 
	(@Fname,@LName, GETDATE(), @CreatedUserId)
RETURN 0



USE [Library]
GO

/****** Object: SqlProcedure [dbo].[InsertBook] Script Date: 03/01/2021 11:55:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[InsertBook]
	@Title varchar,
	@Isbn varchar,
	@CreatedUserId INT
AS
	INSERT INTO [Book] (Title,Isbn,CreatedDate, CreatedUserId) VALUES 
	(@Title,@Isbn, GETDATE(), @CreatedUserId)
RETURN 0


























USE [Library]
GO

/****** Object: SqlProcedure [dbo].[SelectBook] Script Date: 03/01/2021 11:55:03 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SelectBooks]
	
AS
	SELECT Id, Title ,Isbn fROM  [Book] 
RETURN 0


Views 

CREATE VIEW;
[dbo].[ViewLibrary]
	AS SELECT * FROM Library

CREATE VIEW [dbo].[ViewBookCopyPrice];
	AS SELECT * FROM BookCopyPrice 
	Where Price > 1000

CREATE VIEW [dbo].[ViewAuthor];
	AS SELECT * FROM Author

CREATE VIEW [dbo].[ViewBooks];
	AS SELECT B.Title FROM Book B 
	INNER JOIN BookAuthor BA ON BA.BookId  = B.Id
	INNER JOIN Author A ON A.Id = BA.AuthorId










Functions

create function fun_validate_mobile_number  
(  
   @mobileNo varchar(10)    
)  
returns tinyint  
as 
BEGIN
		if(LEN( @mobileNo) <> 10 )
		  return 0

return 1
END

create function fun_validate_bookCopyPrice  
(  
   @BookCopyPrice int
    
)  
returns tinyint  
as 
BEGIN
if(@BookCopyPrice < 0 )
   return 0

return 1
END



	





